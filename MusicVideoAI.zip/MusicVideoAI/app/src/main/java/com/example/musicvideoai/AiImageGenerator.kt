package com.example.musicvideoai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit
import android.util.Base64

/**
 * Generates AI images from text prompts using the Stability AI
 * "Stable Image" REST API (https://platform.stability.ai/docs/api-reference).
 * Each generated image becomes one "scene" in the final music video, so we
 * vary the prompt slightly per scene for visual variety while keeping the
 * user's core style description consistent.
 */
class AiImageGenerator(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val endpoint = "https://api.stability.ai/v2beta/stable-image/generate/core"

    /**
     * @param basePrompt user's style description
     * @param sceneIndex used to add light variation across scenes
     * @param outputFile where the PNG bytes get written
     */
    suspend fun generateImage(basePrompt: String, sceneIndex: Int, outputFile: File): File =
        withContext(Dispatchers.IO) {
            val variedPrompt = "$basePrompt, cinematic scene $sceneIndex, highly detailed, music video still frame"

            val requestBody = MultipartBuilder()
                .addField("prompt", variedPrompt)
                .addField("output_format", "png")
                .addField("aspect_ratio", "9:16")
                .build()

            val request = Request.Builder()
                .url(endpoint)
                .header("Authorization", "Bearer $apiKey")
                .header("Accept", "image/*")
                .post(requestBody.body)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string() ?: "no body"
                    throw IllegalStateException("Image generation failed (${response.code}): $errBody")
                }
                val bytes = response.body!!.bytes()
                outputFile.writeBytes(bytes)
                outputFile
            }
        }

    /**
     * Minimal multipart/form-data builder to avoid pulling in a full
     * multipart dependency for a couple of text fields.
     */
    private class MultipartBuilder {
        private val boundary = "----MusicVideoAIBoundary${System.currentTimeMillis()}"
        private val parts = StringBuilder()

        fun addField(name: String, value: String): MultipartBuilder {
            parts.append("--$boundary\r\n")
            parts.append("Content-Disposition: form-data; name=\"$name\"\r\n\r\n")
            parts.append("$value\r\n")
            return this
        }

        fun build(): BuiltBody {
            parts.append("--$boundary--\r\n")
            val mediaType = "multipart/form-data; boundary=$boundary".toMediaType()
            return BuiltBody(parts.toString().toRequestBody(mediaType))
        }

        class BuiltBody(val body: okhttp3.RequestBody)
    }
}
