package com.example.musicvideoai

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.musicvideoai.databinding.ActivityMainBinding
import java.io.File

@UnstableApi
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var apiKeyManager: ApiKeyManager
    private var selectedSongUri: Uri? = null

    private val pickSongLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            selectedSongUri = uri
            binding.txtSongName.text = uri.lastPathSegment ?: "Song selected"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        apiKeyManager = ApiKeyManager(this)
        apiKeyManager.getKey()?.let { binding.editApiKey.setText(it) }

        binding.btnSaveKey.setOnClickListener {
            val key = binding.editApiKey.text?.toString()?.trim().orEmpty()
            if (key.isNotEmpty()) {
                apiKeyManager.saveKey(key)
                Toast.makeText(this, "API key saved", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnPickSong.setOnClickListener {
            pickSongLauncher.launch(arrayOf("audio/*"))
        }

        binding.btnGenerate.setOnClickListener {
            generateMusicVideo()
        }
    }

    private fun generateMusicVideo() {
        val songUri = selectedSongUri
        val apiKey = apiKeyManager.getKey()
        val prompt = binding.editPrompt.text?.toString()?.trim().orEmpty()

        if (songUri == null) {
            Toast.makeText(this, "Pick a song first", Toast.LENGTH_SHORT).show()
            return
        }
        if (apiKey.isNullOrEmpty()) {
            Toast.makeText(this, "Add your Stability AI API key first", Toast.LENGTH_SHORT).show()
            return
        }
        if (prompt.isEmpty()) {
            Toast.makeText(this, "Describe the visual style", Toast.LENGTH_SHORT).show()
            return
        }

        setBusy(true, "Analyzing beat...")

        CoroutineScope(Dispatchers.Main).launch {
            try {
                // 1. Detect beats in the chosen song
                val beatResult = withContext(Dispatchers.Default) {
                    BeatDetector().detectBeats(this@MainActivity, songUri)
                }
                val beats = beatResult.beatTimestampsMs
                if (beats.size < 2) {
                    throw IllegalStateException("Couldn't find enough beats in this track")
                }

                // 2. Compute how long each scene should last (gap to next beat)
                val sceneDurations = ArrayList<Long>()
                for (i in beats.indices) {
                    val end = if (i + 1 < beats.size) beats[i + 1] else beatResult.durationMs
                    sceneDurations.add((end - beats[i]).coerceAtLeast(300L))
                }

                // Cap scene count so we don't hammer the API / blow past free-tier limits
                val maxScenes = 20
                val cappedDurations = sceneDurations.take(maxScenes)

                // 3. Generate one AI image per scene
                setBusy(true, "Generating ${cappedDurations.size} AI scenes...")
                val generator = AiImageGenerator(apiKey)
                val imagesDir = File(cacheDir, "scenes").apply { mkdirs() }
                val images = ArrayList<File>()
                for (i in cappedDurations.indices) {
                    setBusy(true, "Generating scene ${i + 1}/${cappedDurations.size}...")
                    val out = File(imagesDir, "scene_$i.png")
                    images.add(withContext(Dispatchers.IO) {
                        generator.generateImage(prompt, i, out)
                    })
                }

                // 4. Assemble images + original audio into the final video
                setBusy(true, "Rendering final video...")
                val outputFile = File(
                    getExternalFilesDir(Environment.DIRECTORY_MOVIES),
                    "musicvideo_${System.currentTimeMillis()}.mp4"
                )
                VideoComposer(this@MainActivity).compose(
                    images = images,
                    sceneDurationsMs = cappedDurations,
                    audioUri = songUri,
                    outputFile = outputFile
                )

                // 5. Make it visible in the device's gallery/Movies
                saveToMediaStore(outputFile)

                setBusy(false, "Done! Saved to Movies: ${outputFile.name}")
            } catch (e: Exception) {
                setBusy(false, "Error: ${e.message}")
            }
        }
    }

    private fun saveToMediaStore(file: File) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MusicVideoAI")
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        uri?.let { dest ->
            contentResolver.openOutputStream(dest)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
        }
    }

    private fun setBusy(busy: Boolean, status: String) {
        binding.progressBar.visibility = if (busy) android.view.View.VISIBLE else android.view.View.GONE
        binding.txtStatus.text = status
        binding.btnGenerate.isEnabled = !busy
    }
}
