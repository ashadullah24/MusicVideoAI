package com.example.musicvideoai

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.Transformer
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * Combines a sequence of generated images (one per beat/scene) into a single
 * exported video whose cuts land on the beat timestamps, then muxes in the
 * original song as the audio track.
 */
@UnstableApi
class VideoComposer(private val context: Context) {

    /**
     * @param images ordered list of image files, one per scene
     * @param sceneDurationsMs how long each image should be shown, in ms
     *        (derived from gaps between detected beats)
     * @param audioUri the original song, used as the export's audio track
     * @param outputFile destination .mp4 file
     */
    suspend fun compose(
        images: List<File>,
        sceneDurationsMs: List<Long>,
        audioUri: Uri,
        outputFile: File
    ) {
        require(images.size == sceneDurationsMs.size) {
            "Each image needs a matching scene duration"
        }
        if (outputFile.exists()) outputFile.delete()

        val imageItems = images.mapIndexed { index, file ->
            val durationMs = sceneDurationsMs[index].coerceAtLeast(300L) // avoid degenerate 0-length scenes
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.fromFile(file))
                .build()

            // Slow pan/zoom (Ken Burns) so static AI images don't feel frozen.
            val zoomEffect = ScaleAndRotateTransformation.Builder()
                .setScale(1.08f, 1.08f)
                .build()

            EditedMediaItem.Builder(mediaItem)
                .setDurationUs(durationMs * 1000)
                .setFrameRate(30)
                .setEffects(Effects(emptyList(), listOf(zoomEffect)))
                .build()
        }

        val imageSequence = EditedMediaItemSequence(imageItems)

        val audioItem = EditedMediaItem.Builder(MediaItem.fromUri(audioUri)).build()
        val audioSequence = EditedMediaItemSequence(listOf(audioItem))

        val composition = Composition.Builder(listOf(imageSequence, audioSequence))
            .build()

        suspendCoroutine<Unit> { cont ->
            val transformer = Transformer.Builder(context)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, result: androidx.media3.transformer.ExportResult) {
                        cont.resume(Unit)
                    }

                    override fun onError(
                        composition: Composition,
                        result: androidx.media3.transformer.ExportResult,
                        exception: androidx.media3.transformer.ExportException
                    ) {
                        cont.resumeWithException(exception)
                    }
                })
                .build()

            transformer.start(composition, outputFile.absolutePath)
        }
    }
}
