package com.example.musicvideoai

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max

/**
 * Decodes an audio file and detects beat timestamps using a simple
 * energy-based onset detection algorithm:
 *   1. Decode audio to PCM (mono, downmixed).
 *   2. Split into ~46ms windows and compute RMS energy per window.
 *   3. Compute a local moving-average threshold.
 *   4. Flag a window as a beat/onset if its energy exceeds the local
 *      threshold by a margin, with a minimum gap between onsets so we
 *      don't fire multiple times on the same transient.
 *
 * This is not a music-theory-grade beat tracker, but it reliably finds
 * strong transients (kicks/snares/onsets) which is enough to sync
 * visual cuts to the music.
 */
class BeatDetector {

    data class Result(val beatTimestampsMs: List<Long>, val durationMs: Long)

    fun detectBeats(context: Context, uri: Uri): Result {
        val pcm = decodeToPcm(context, uri)
        val beats = findOnsets(pcm.samples, pcm.sampleRate)
        return Result(beats, pcm.durationMs)
    }

    private data class PcmData(val samples: ShortArray, val sampleRate: Int, val durationMs: Long)

    private fun decodeToPcm(context: Context, uri: Uri): PcmData {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)

        var trackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                trackIndex = i
                format = f
                break
            }
        }
        require(trackIndex >= 0 && format != null) { "No audio track found" }
        extractor.selectTrack(trackIndex)

        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val channelCount = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT))
            format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1
        val durationMs = if (format.containsKey(MediaFormat.KEY_DURATION))
            format.getLong(MediaFormat.KEY_DURATION) / 1000 else 0L

        val output = ArrayList<Short>(sampleRate * 60) // rough pre-size guess
        val bufferInfo = MediaCodec.BufferInfo()
        var sawInputEOS = false
        var sawOutputEOS = false

        while (!sawOutputEOS) {
            if (!sawInputEOS) {
                val inIndex = codec.dequeueInputBuffer(10_000)
                if (inIndex >= 0) {
                    val inputBuffer: ByteBuffer = codec.getInputBuffer(inIndex)!!
                    val sampleSize = extractor.readSampleData(inputBuffer, 0)
                    if (sampleSize < 0) {
                        codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        sawInputEOS = true
                    } else {
                        val presentationTimeUs = extractor.sampleTime
                        codec.queueInputBuffer(inIndex, 0, sampleSize, presentationTimeUs, 0)
                        extractor.advance()
                    }
                }
            }

            val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
            if (outIndex >= 0) {
                val outputBuffer: ByteBuffer = codec.getOutputBuffer(outIndex)!!
                outputBuffer.order(ByteOrder.LITTLE_ENDIAN)
                val shortBuffer = outputBuffer.asShortBuffer()
                val chunk = ShortArray(shortBuffer.remaining())
                shortBuffer.get(chunk)

                // Downmix to mono if needed
                if (channelCount > 1) {
                    var i = 0
                    while (i + channelCount <= chunk.size) {
                        var sum = 0
                        for (c in 0 until channelCount) sum += chunk[i + c]
                        output.add((sum / channelCount).toShort())
                        i += channelCount
                    }
                } else {
                    for (s in chunk) output.add(s)
                }

                codec.releaseOutputBuffer(outIndex, false)
                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    sawOutputEOS = true
                }
            }
        }

        codec.stop()
        codec.release()
        extractor.release()

        return PcmData(output.toShortArray(), sampleRate, durationMs)
    }

    private fun findOnsets(samples: ShortArray, sampleRate: Int): List<Long> {
        if (samples.isEmpty()) return emptyList()

        val windowMs = 46.0 // ~1024 samples at 44.1kHz
        val windowSize = max(256, (sampleRate * windowMs / 1000).toInt())
        val numWindows = samples.size / windowSize
        if (numWindows == 0) return emptyList()

        val energies = DoubleArray(numWindows)
        for (w in 0 until numWindows) {
            var sum = 0.0
            val start = w * windowSize
            for (i in start until start + windowSize) {
                val v = samples[i].toDouble() / Short.MAX_VALUE
                sum += v * v
            }
            energies[w] = Math.sqrt(sum / windowSize)
        }

        // Local moving average threshold (looks back ~1 second)
        val historyWindows = max(1, (1000 / windowMs).toInt())
        val onsets = ArrayList<Long>()
        var lastOnsetWindow = -1000
        val minGapWindows = max(1, (200 / windowMs).toInt()) // min 200ms between beats

        for (w in 0 until numWindows) {
            val histStart = max(0, w - historyWindows)
            var avg = 0.0
            for (i in histStart until w) avg += energies[i]
            val count = w - histStart
            avg = if (count > 0) avg / count else energies[w]

            val threshold = avg * 1.4 + 0.02
            if (energies[w] > threshold && (w - lastOnsetWindow) > minGapWindows) {
                val timestampMs = (w * windowSize.toDouble() / sampleRate * 1000).toLong()
                onsets.add(timestampMs)
                lastOnsetWindow = w
            }
        }

        // Fallback: if too few onsets detected (very quiet/ambient track),
        // space evenly every 2 seconds so the video still has cuts.
        if (onsets.size < 4) {
            val durationMs = (samples.size.toDouble() / sampleRate * 1000).toLong()
            onsets.clear()
            var t = 0L
            while (t < durationMs) {
                onsets.add(t)
                t += 2000
            }
        }

        return onsets
    }
}
