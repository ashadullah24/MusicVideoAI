# MusicVideoAI (Android)

Pick a song → the app detects the beat → generates one AI image per beat/scene
via the Stability AI API → stitches them into an MP4 with pan/zoom cuts timed
to the beat, muxed with your original audio.

## How it works
1. **BeatDetector.kt** — decodes the song to PCM (MediaExtractor/MediaCodec),
   computes energy per ~46ms window, and flags onsets that spike above a
   local moving-average threshold. Falls back to even 2s cuts for very quiet
   tracks so you always get a video.
2. **AiImageGenerator.kt** — calls Stability AI's `stable-image/generate/core`
   endpoint once per detected scene, varying the prompt slightly per scene.
3. **VideoComposer.kt** — uses AndroidX Media3 Transformer to build a
   Composition from the generated images (each shown for its beat-gap
   duration, with a slow zoom) and muxes in the original song as audio,
   exporting a single .mp4 to `Movies/MusicVideoAI`.
4. **MainActivity.kt** — the UI: enter your API key, pick a song, describe a
   visual style, tap Generate.

## Building from just a phone (no computer) — GitHub Actions

This project includes `.github/workflows/build.yml`, which builds the APK
in the cloud automatically. All of this can be done from your phone's
browser:

1. Go to **github.com**, sign up/log in (free).
2. Tap **+ → New repository**, name it `MusicVideoAI`, keep it Public (or
   Private, doesn't matter), create it.
3. On the new repo page, tap **Add file → Upload files**, then upload every
   file/folder from the extracted `MusicVideoAI` zip (your phone's file
   manager should let you select the whole extracted folder's contents —
   if it only lets you pick files one at a time, a Files app with
   "select multiple" works fine, just preserve the folder structure).
4. Commit the upload (this triggers the workflow automatically since it
   watches pushes to `main`).
5. Go to the **Actions** tab of your repo → you'll see "Build APK" running
   (takes a few minutes).
6. When it finishes (green checkmark), open that run → scroll to
   **Artifacts** → tap **MusicVideoAI-debug-apk** to download it — this
   downloads a `.zip` containing `app-debug.apk`.
7. On your phone, extract that zip, tap `app-debug.apk` to install it
   (you'll need to allow "install from unknown sources" the first time —
   Android will prompt you with a settings shortcut when you tap the file).
8. Open the app, paste your Stability AI key, pick a song, and generate.

## Setup (if you do have a computer later)
1. Install **Android Studio** (Koala or newer).
2. `File > Open` and select this project folder — Android Studio will
   generate the Gradle wrapper jar automatically on first sync (it needs
   internet access once, to download Gradle 8.4 and the dependencies listed
   in `app/build.gradle`).
3. Get a free/paid API key at https://platform.stability.ai/account/keys
4. Run on a device or emulator (**minSdk 26**, Android 8.0+).
5. In the app: paste your API key → tap **Save Key** → **Choose Song** →
   type a style prompt (e.g. "neon cyberpunk city, rain, slow motion") →
   **Generate Music Video**.

## Known limitations / things to double check
- **API costs**: each generated image is a billed API call — a 20-scene
  video makes 20 calls. The app caps scenes at 20 to control cost; change
  `maxScenes` in `MainActivity.kt` if you want more/fewer.
- **Media3 Transformer API surface** changes between versions. This project
  pins `media3-transformer:1.3.1`; if Android Studio flags
  `ScaleAndRotateTransformation` or `EditedMediaItem` signatures as
  mismatched, check the Media3 release notes for that version and adjust —
  the effect/scale API has moved around across 1.2.x/1.3.x/1.4.x.
- **Beat detection** is energy/onset-based, not a full music-theory BPM
  tracker. It works well for tracks with clear percussive hits; ambient or
  very smooth tracks will fall back to fixed 2-second cuts.
- You'll need to add your own launcher icon at
  `app/src/main/res/mipmap/ic_launcher.png` (or generate one via Android
  Studio's Image Asset tool) — none is included here.
- No `gradle-wrapper.jar` binary is included (binary files can't be
  generated here); opening the project in Android Studio creates it
  automatically, or run `gradle wrapper` locally if you have Gradle
  installed.

## Swapping the AI provider
`AiImageGenerator.kt` is isolated on purpose — to use a different
text-to-image API (e.g. an OpenAI Images endpoint or a self-hosted Stable
Diffusion server), you only need to rewrite that one file's `generateImage`
function; the rest of the app (beat detection, video assembly) stays the
same.
